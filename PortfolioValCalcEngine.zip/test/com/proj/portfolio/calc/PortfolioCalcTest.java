package com.proj.portfolio.calc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.proj.portfolio.trade.Side;
import com.proj.portfolio.trade.Trade;

import junit.framework.Assert;

public class PortfolioCalcTest {

	@Test
	public void testPositionCalc() throws PriceNotPublished {
		Map<String, Double> currentPrice = generatePriceMap("INFY", "INFY1000P201703", "RELI1000C201703");
		List<Trade> trades=new ArrayList<>();
		double expectedTotalPortFolioValue;
		Trade trade = generateTrade("INFY", 100, Side.BUY);
		trades.add(trade);
		expectedTotalPortFolioValue=trade.getQty()*currentPrice.get(trade.getTicker());
		Assert.assertEquals(trade.getQty() * currentPrice.get(trade.getTicker()),
				PortfolioCalc.calculatePostionValue(trade, currentPrice.get("INFY")));
		trade = generateTrade("INFY", 100, Side.SELL);
		trades.add(trade);
		expectedTotalPortFolioValue-=trade.getQty()*currentPrice.get(trade.getTicker());
		Assert.assertEquals(-trade.getQty() * currentPrice.get(trade.getTicker()),
				PortfolioCalc.calculatePostionValue(trade, currentPrice.get("INFY")));
		trade = generateTrade("INFY1000P201703", 1000, Side.BUY);
		trades.add(trade);
		expectedTotalPortFolioValue+=trade.getQty()*currentPrice.get(trade.getTicker());
		Assert.assertEquals(trade.getQty() * currentPrice.get(trade.getTicker()),
				PortfolioCalc.calculatePostionValue(trade, currentPrice.get("INFY1000P201703")));
		
		Assert.assertEquals(expectedTotalPortFolioValue, PortfolioCalc.calculatePortfolioValue(trades,currentPrice));
		
	}

	@Test(expected = PriceNotPublished.class)
	public void testPositionCalcWhenPriceNotFound() throws PriceNotPublished {
		Map<String, Double> currentPrice = generatePriceMap("INFY", "INFY1000P201703", "RELI1000C201703");
		Trade trade = generateTrade("TCS", 100, Side.BUY);
		PortfolioCalc.calculatePostionValue(trade, currentPrice.get(trade.getTicker()));
	}

	private Trade generateTrade(String ticker, double qty, Side side) {
		Trade trade = new Trade();
		trade.setQty(qty);
		trade.setSide(side);
		trade.setTicker(ticker);
		return trade;
	}

	private Map<String, Double> generatePriceMap(String... tickers) {
		Map<String, Double> priceMap = new HashMap<>();

		for (String ticker : tickers) {
			priceMap.put(ticker, Math.random() * 100);
		}
		return priceMap;
	}
}
