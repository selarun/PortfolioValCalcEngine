package com.proj.portfolio.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = { "classpath:test-db-context.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class InstrumentLoaderEmbeddedTest {

	@Autowired
	private InstrumentLoaderDAO instrumentLoaderDAO;

	@Test
	public void testContext() {
		assertNotNull(instrumentLoaderDAO);
	}

	@Test
	public void testDataLoaded() {
		assertEquals(4, instrumentLoaderDAO.getAllStocks().size());
		assertEquals(4, instrumentLoaderDAO.getAllOptions().size());
	}

}