package com.proj.portfolio.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentManager;
import com.proj.portfolio.instrument.InstrumentNotFoundException;

@ContextConfiguration(locations = { "classpath:test-db-context.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class InstrumentManagerEmbeddedTest {

	@Autowired
	private InstrumentManager instrumentManager;

	@Test
	public void testContext() {
		assertNotNull(instrumentManager);
	}

	@Test
	public void testStockDataLoadedSucessfully() throws InstrumentNotFoundException {
		assertNotNull(instrumentManager.findInstrumentByTicker("INFY"));
		assertNotNull(instrumentManager.findInstrumentByTicker("RELI"));

	}

	@Test(expected = InstrumentNotFoundException.class)
	public void testStockDataNotAvaiable() throws InstrumentNotFoundException {
		instrumentManager.findInstrumentByTicker("SSSS");
	}

	@Test
	public void testOptionDataLoadedSucessfully() throws InstrumentNotFoundException {
		assertNotNull(instrumentManager.findInstrumentByTicker("INFY1000P201709"));
		assertNotNull(instrumentManager.findInstrumentByTicker("RELI5000P201709"));

	}

	@Test(expected = InstrumentNotFoundException.class)
	public void testOptionDataNotAvaiable() throws InstrumentNotFoundException {
		assertNotNull(instrumentManager.findInstrumentByTicker("INFY1000P201701"));

	}

	@Test
	public void testOptionUnderLierData() throws InstrumentNotFoundException {
		Instrument infyStock = instrumentManager.findInstrumentByTicker("INFY");
		Instrument infyOpt = instrumentManager.findInstrumentByTicker("INFY1000P201709");
		assertNotNull(infyStock);
		assertNotNull(infyOpt);
		assertEquals(infyStock.getTicker(), infyOpt.getUnderlyingTicker());
		assertEquals(infyStock.getClosePx(), infyOpt.getUnderlyingClosePrice(),0);
		assertEquals(infyStock.getStandardDeviation(), infyOpt.getUnderlyingStandardDeviation(),0);

	}

}