package com.proj.portfolio.marketdata;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import org.junit.BeforeClass;
import org.junit.Test;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentNotValid;
import com.proj.portfolio.trade.OptionType;

import junit.framework.Assert;

public class OptionPriceGeneratorTest {

	private static OptionPriceGenerator optionPriceGenerator;

	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd");
	private static final SimpleDateFormat YEAR_MONTH_DATE_FORMAT = new SimpleDateFormat("yyyyMM");

	@BeforeClass
	public static void setUp() {
		optionPriceGenerator = new OptionPriceGenerator();
	}

	@Test
	public void testOptionPriceGenerationForZeroTimeToMaturity() throws InstrumentNotValid {
		Date currdate = Calendar.getInstance().getTime();

		assertEquals(-200d,
				optionPriceGenerator
						.generateOptionPrice(generateInstrument("INFY1000P" + YEAR_MONTH_DATE_FORMAT.format(currdate),
								100d, 0.5, currdate, 1000, OptionType.PUT), 1200));
		assertEquals(200d,
				optionPriceGenerator
						.generateOptionPrice(generateInstrument("INFY1000C" + YEAR_MONTH_DATE_FORMAT.format(currdate),
								100d, 0.5, currdate, 1000, OptionType.CALL), 1200));
	}

	@Test(expected = InstrumentNotValid.class)
	public void testOptionPriceGenerationForZeroSTDUnderlyierStockPrice() throws InstrumentNotValid, ParseException {
		optionPriceGenerator.generateOptionPrice(
				generateInstrument("INFY1000P201712", 0, 0, DATE_FORMAT.parse("2017/12/12"), 1000, OptionType.PUT), 0);

	}
	
	
	@Test(expected = InstrumentNotValid.class)
	public void testOptionPriceGenerationForInvalidStrikePrice() throws InstrumentNotValid, ParseException {
		optionPriceGenerator.generateOptionPrice(
				generateInstrument("INFY1000P201712", 100, 0.4, DATE_FORMAT.parse("2017/12/12"), 0, OptionType.PUT), 0);

	}

	@Test
	public void testOptionPriceGenerationForValidCase() throws InstrumentNotValid, ParseException {
		double optionPrice=optionPriceGenerator.generateOptionPrice(generateInstrument("INFY1000P201712",
				120d, 0.5,DATE_FORMAT.parse("2017/12/12"), 1000, OptionType.PUT), 1200);		
		assertNotNull(optionPrice);
		optionPrice=optionPriceGenerator.generateOptionPrice(generateInstrument("INFY1000C201712",
				120d, 0.5,DATE_FORMAT.parse("2017/12/12"), 1000, OptionType.CALL), 1200);		
		Assert.assertNotNull(optionPrice);
		//Longer the TimeToMaturity, premium of the option is more 
		Assert.assertTrue(optionPrice < optionPriceGenerator.generateOptionPrice(generateInstrument("INFY1000C201712",
				120d, 0.5,DATE_FORMAT.parse("2018/12/12"), 1000, OptionType.CALL), 1200));		
		
	}

	private Instrument generateInstrument(String ticker, double underlyingClosepx, double underlyingSTD,
			Date maturityDate, double strikeprice, OptionType optionType) {
		Instrument instrument = new Instrument();
		instrument.setTicker(ticker);
		instrument.setUnderlyingClosePrice(underlyingClosepx);
		instrument.setUnderlyingStandardDeviation(underlyingSTD);
		instrument.setMaturityDate(maturityDate);
		instrument.setStrikePrice(strikeprice);
		instrument.setOptionType(optionType);
		return instrument;
	}
}
