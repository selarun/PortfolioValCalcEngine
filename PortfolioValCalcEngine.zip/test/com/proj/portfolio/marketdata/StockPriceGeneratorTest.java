package com.proj.portfolio.marketdata;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotSame;

import org.junit.BeforeClass;
import org.junit.Test;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentNotValid;

public class StockPriceGeneratorTest {

	private static StockPriceGenerator stockPriceGenerator;

	@BeforeClass
	public static void setUp() {
		stockPriceGenerator = new StockPriceGenerator();
	}

	@Test(expected = InstrumentNotValid.class)
	public void testStockPriceGeneratorWithZeroSTD() throws InstrumentNotValid {
		stockPriceGenerator.generateStockPrice(generateInstrument("INFY", 0.5, 0, 0), 200, 1000l);
	}

	@Test(expected = InstrumentNotValid.class)
	public void testStockPriceGeneratorWithZeroROE() throws InstrumentNotValid {
		stockPriceGenerator.generateStockPrice(generateInstrument("INFY", 0.0, 0, 0), 200, 1000l);
	}

	@Test
	public void testStockPriceGeneratorWithValidValues() throws InstrumentNotValid {
		long lastPublishedTime = System.currentTimeMillis();
		assertEquals(200d,
				stockPriceGenerator.generateStockPrice(generateInstrument("INFY", 100, 0.5, 0.5), 200, 0l));
		assertNotSame(200d, stockPriceGenerator.generateStockPrice(generateInstrument("INFY", 100, 0.5, 0.5),
				200, lastPublishedTime - 3000));

	}

	private Instrument generateInstrument(String ticker, double closepx, double roe, double std) {
		Instrument instrument = new Instrument();
		instrument.setClosePx(closepx);
		instrument.setTicker(ticker);
		instrument.setRoe(roe);
		instrument.setStandardDeviation(std);
		return instrument;
	}
}
