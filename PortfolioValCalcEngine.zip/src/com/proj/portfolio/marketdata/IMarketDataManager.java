package com.proj.portfolio.marketdata;

public interface IMarketDataManager {

	void subscribe(String ticker);
	
	void register(ITopOfBookListener bookListener);
}
