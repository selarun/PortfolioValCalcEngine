package com.proj.portfolio.marketdata;

public interface ITopOfBookListener {

	void updateMarketData(MarketData marketData);
}
