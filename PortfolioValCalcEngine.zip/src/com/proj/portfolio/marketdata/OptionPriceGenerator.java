package com.proj.portfolio.marketdata;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.math3.distribution.NormalDistribution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentNotValid;
import com.proj.portfolio.trade.OptionType;

public class OptionPriceGenerator {
	private static final Logger logger = LoggerFactory.getLogger(OptionPriceGenerator.class);
	
	private static final int RISK_FREE_INTEREST_PER_ANNUM = 2;
	private static final Date currentDate = Calendar.getInstance().getTime();

	/**
	 * A normal distribution. We'll reuse this across different calculations.
	 */
	private NormalDistribution normalDistribution = new NormalDistribution(0, 1);

	public double generateOptionPrice(Instrument instrument, double currentSpotPriceOfStock) throws InstrumentNotValid {

		if (!validateInstrumentData(instrument)) {
			throw new InstrumentNotValid("Instrument Data is not correct");

		}

		long noofDays = getDifferenceDays(currentDate, instrument.getMaturityDate());

		// it was used 252 as no of business days instead of 365 working days
		long timeToMaturity = noofDays / 252;

		final double d1 = this.d1(currentSpotPriceOfStock, instrument, timeToMaturity);
		final double d2 = this.d2(instrument.getUnderlyingStandardDeviation(), timeToMaturity, d1);
		Double price = null;
		if (instrument.getOptionType() == OptionType.CALL) {
			if (timeToMaturity == 0) {
				price = currentSpotPriceOfStock - instrument.getStrikePrice();
			} else {
				price = currentSpotPriceOfStock * normalDistribution.cumulativeProbability(d1);
				price -= normalDistribution.cumulativeProbability(d2) * instrument.getStrikePrice()
						* Math.exp(-RISK_FREE_INTEREST_PER_ANNUM * timeToMaturity);
			}
		} else if (instrument.getOptionType() == OptionType.PUT) {
			if (timeToMaturity == 0) {
				price = instrument.getStrikePrice() - currentSpotPriceOfStock;
			} else {
				price = normalDistribution.cumulativeProbability(-d2) * instrument.getStrikePrice()
						* Math.exp(-RISK_FREE_INTEREST_PER_ANNUM * timeToMaturity);
				price -= currentSpotPriceOfStock * normalDistribution.cumulativeProbability(-d1);
			}
		}
		logger.info("Generated Option price for ticker : {} is {}", instrument.getTicker(), price);

		return price;
	}

	private boolean validateInstrumentData(Instrument instrument) {
		if (instrument.getMaturityDate().before(currentDate)) {
			logger.error("Option have already expired.Fix the position file and retry");
			return false;
		} else if (instrument.getStrikePrice() <= 0) {
			logger.error("Invalid StrikePrice . Fix the Instrument Data:{}", instrument);
			return false;

		} else if (instrument.getUnderlyingStandardDeviation() <= 0) {
			logger.error("Invalid STD for underlying Stock.Fix the Instrument Data :{}", instrument);
			return false;

		}

		return true;
	}

	public static long getDifferenceDays(Date d1, Date d2) {
		long diff = d2.getTime() - d1.getTime();
		return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}

	/**
	 * Part of the BS calculation
	 * 
	 * @currentSpotPriceOfStock - Current spot price of the underlying stock
	 * @instrument Instrument
	 * @timeToMaturity- Time to maturity from current day
	 * @param d1
	 *            The d1 part of the Black-Scholes formula
	 * @return The d1 part of the Black-Scholes formula
	 */
	private double d1(double currentSpotPriceOfStock, Instrument instrument, long timeToMaturity) {
		double retVal = Math.log(currentSpotPriceOfStock / instrument.getStrikePrice());
		retVal += (RISK_FREE_INTEREST_PER_ANNUM
				+ instrument.getUnderlyingStandardDeviation() * instrument.getUnderlyingStandardDeviation() / 2.f)
				* timeToMaturity;
		retVal /= instrument.getUnderlyingStandardDeviation() * Math.sqrt(timeToMaturity);
		return retVal;
	}

	/**
	 * Part of the BS calculation
	 * 
	 * underlyingSTD - Standard Deviation for Underlying Stock
	 * 
	 * @timeToMaturity- Time to maturity from current day
	 * @param d1
	 *            The d1 part of the Black-Scholes formula
	 * @return The d2 part of the Black-Scholes formula
	 * 
	 */
	private double d2(double underlyingSTD, long timeToMaturity, double d1) {
		return (d1 - underlyingSTD * Math.sqrt(timeToMaturity));
	}

}
