package com.proj.portfolio.marketdata;

import com.proj.portfolio.instrument.InstrumentNotFoundException;
import com.proj.portfolio.instrument.InstrumentNotValid;

public interface IMarketDataProvider {

	public MarketData getPrice(String ticker) throws InstrumentNotFoundException, InstrumentNotValid;
}