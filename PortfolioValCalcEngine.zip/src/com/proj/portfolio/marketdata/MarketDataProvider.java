package com.proj.portfolio.marketdata;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentManager;
import com.proj.portfolio.instrument.InstrumentNotFoundException;
import com.proj.portfolio.instrument.InstrumentNotValid;
import com.proj.portfolio.trade.ProductType;

public class MarketDataProvider implements IMarketDataProvider {

	private final Map<String, MarketData> currentPriceForTicker = new ConcurrentHashMap<>();

	private StockPriceGenerator stockPriceGenerator;
	private OptionPriceGenerator optionPriceGenerator;

	public StockPriceGenerator getStockPriceGenerator() {
		return stockPriceGenerator;
	}

	public OptionPriceGenerator getOptionPriceGenerator() {
		return optionPriceGenerator;
	}

	public void setStockPriceGenerator(StockPriceGenerator stockPriceGenerator) {
		this.stockPriceGenerator = stockPriceGenerator;
	}

	public void setOptionPriceGenerator(OptionPriceGenerator optionPriceGenerator) {
		this.optionPriceGenerator = optionPriceGenerator;
	}

	public MarketData getPrice(String ticker) throws InstrumentNotFoundException, InstrumentNotValid {
		MarketData marketData = currentPriceForTicker.get(ticker);
		Instrument instrument = InstrumentManager.getInstance().findInstrumentByTicker(ticker);
		if (marketData == null) {
			marketData = new MarketData();
		}

		marketData.setTicker(ticker);

		if (instrument.getProductType() == ProductType.STOCK) {
			long lastPublishedTimeStamp = marketData.getTimeStamp();
			if (lastPublishedTimeStamp == 0)
				marketData.setCurrentPrice(
						stockPriceGenerator.generateStockPrice(instrument, instrument.getClosePx(), 0));
			else
				marketData.setCurrentPrice(stockPriceGenerator.generateStockPrice(instrument,
						marketData.getCurrentPrice(), lastPublishedTimeStamp));

		}
		if (instrument.getProductType() == ProductType.OPTION) {
			// get underlyier spot price
			MarketData underLyierMarketData = currentPriceForTicker.get(instrument.getUnderlyingTicker());
			Instrument underLyierInstrument = InstrumentManager.getInstance()
					.findInstrumentByTicker(instrument.getUnderlyingTicker());
			double currentStockPrice;
			if (underLyierMarketData == null) {
				underLyierMarketData = new MarketData();
				underLyierMarketData.setTicker(instrument.getUnderlyingTicker());
				// invoke generate stock price since it may not be in the
				// subscribed list
				currentStockPrice = stockPriceGenerator.generateStockPrice(underLyierInstrument,
						underLyierInstrument.getClosePx(), 0);
				marketData.setCurrentPrice(optionPriceGenerator.generateOptionPrice(instrument, currentStockPrice));
			} else {
				currentStockPrice = stockPriceGenerator.generateStockPrice(underLyierInstrument,
						underLyierMarketData.getCurrentPrice(), underLyierMarketData.getTimeStamp());
				marketData.setCurrentPrice(optionPriceGenerator.generateOptionPrice(instrument, currentStockPrice));
			}
			underLyierMarketData.setCurrentPrice(currentStockPrice);
			underLyierMarketData.setTimeStamp(System.currentTimeMillis());
			currentPriceForTicker.put(underLyierMarketData.getTicker(), underLyierMarketData);

		}
		marketData.setTimeStamp(System.currentTimeMillis());
		currentPriceForTicker.put(ticker, marketData);
		return marketData;
	}

}
