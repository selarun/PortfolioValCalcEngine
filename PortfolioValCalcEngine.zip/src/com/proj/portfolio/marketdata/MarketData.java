package com.proj.portfolio.marketdata;

public class MarketData {
	private String ticker;
	private Double currentPrice;
	private long timeStamp;

	public String getTicker() {
		return ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public Double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}

	@Override
	public String toString() {
		return "MarketData [ticker=" + ticker + ", currentPrice=" + currentPrice + "]";
	}

}
