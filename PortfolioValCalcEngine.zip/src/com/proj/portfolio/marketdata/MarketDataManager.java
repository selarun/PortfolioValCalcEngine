package com.proj.portfolio.marketdata;

import java.util.HashSet;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.proj.portfolio.instrument.InstrumentNotFoundException;
import com.proj.portfolio.instrument.InstrumentNotValid;

public class MarketDataManager implements IMarketDataManager {

	private static final Logger logger = LoggerFactory.getLogger(MarketDataManager.class);
	
	HashSet<String> subscribedTickers = new HashSet<>();

	@Autowired
	private ITopOfBookListener bookListener;

	@Autowired
	private IMarketDataProvider marketDataProvider;

	private MarketDataUpdater dataUpdater = new MarketDataUpdater();
	private Timer timer = new Timer();

	private boolean timerScheduled;
	private Random rand = new Random();

	@Override
	public void subscribe(String ticker) {
		subscribedTickers.add(ticker);
		if (!timerScheduled) {
			timer.schedule(dataUpdater, 5000);
			timerScheduled = true;
		}

	}

	@Override
	public void register(ITopOfBookListener bookListener) {
		this.bookListener = bookListener;
	}

	public ITopOfBookListener getBookListener() {
		return bookListener;
	}

	public void setBookListener(ITopOfBookListener bookListener) {
		this.bookListener = bookListener;
	}

	public IMarketDataProvider getMarketDataProvider() {
		return marketDataProvider;
	}

	public void setMarketDataProvider(IMarketDataProvider marketDataProvider) {
		this.marketDataProvider = marketDataProvider;
	}

	class MarketDataUpdater extends TimerTask {
		@Override
		public void run() {
			int delay = 500 + rand.nextInt(1500); // Randon b/w 0.5 - 2 sec

			logger.debug("Trigger the timer for marketData with delay {}",delay);
			timer.schedule(new MarketDataUpdater(), delay);
			try {
				triggerMarketDataPublishes();
			} catch (InstrumentNotFoundException e) {
				logger.error(e.getMessage());
				System.exit(-1);
			} catch (InstrumentNotValid e) {				
				logger.error(e.getMessage());
				System.exit(-1);
			}

		}

		private void triggerMarketDataPublishes() throws InstrumentNotFoundException, InstrumentNotValid {
			for (String ticker : subscribedTickers) {
				bookListener.updateMarketData(marketDataProvider.getPrice(ticker));
			}
		}
	}
}