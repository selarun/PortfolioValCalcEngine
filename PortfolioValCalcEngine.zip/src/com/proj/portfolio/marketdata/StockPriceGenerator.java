package com.proj.portfolio.marketdata;

import org.apache.commons.math3.distribution.NormalDistribution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.instrument.InstrumentNotValid;

public class StockPriceGenerator {

	private static final Logger logger = LoggerFactory.getLogger(StockPriceGenerator.class);

	public double generateStockPrice(Instrument instrument, double prevStockPrice, long lastPublishTime) throws InstrumentNotValid {
		logger.info("Calculating Stock price for instrument : {}", instrument);

		if(!validateInstrumentData(instrument)) {
			throw new InstrumentNotValid("Instrument Data is not correct :"+instrument);
		}
		if (lastPublishTime == 0) {
			return prevStockPrice;
		}

		long currentTimeStamp = System.currentTimeMillis();
		long lastTimeDiffInSecs = currentTimeStamp - lastPublishTime;

		double timecalc = lastTimeDiffInSecs / 1000;

		NormalDistribution distribution = new NormalDistribution(instrument.getRoe(),
				instrument.getStandardDeviation());

		double dd = instrument.getStandardDeviation() * distribution.sample() * Math.sqrt(timecalc);
		double cc = instrument.getRoe() * timecalc;

		double genStockPrice = prevStockPrice + (prevStockPrice * (cc + dd));
		logger.info("Generated Stock price for ticker : {} is {} ", instrument.getTicker(), genStockPrice);

		return genStockPrice;

	}

	private boolean validateInstrumentData(Instrument instrument) {
		 if (instrument.getClosePx() < 0) {
			logger.error("Invalid ClosePx . Fix the Instrument Data:{}", instrument);
			return false;

		} else if (instrument.getStandardDeviation() <= 0) {
			logger.error("Invalid STD for  Stock.Fix the Instrument Data :{}", instrument);
			return false;

		}

		return true;
	}

}
