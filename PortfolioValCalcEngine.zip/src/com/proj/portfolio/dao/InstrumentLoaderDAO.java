package com.proj.portfolio.dao;

import java.util.Collection;

import com.proj.portfolio.instrument.Instrument;

public interface InstrumentLoaderDAO {

	public Collection<Instrument> getAllStocks();
	
	public Collection<Instrument> getAllOptions();
		
	
}
