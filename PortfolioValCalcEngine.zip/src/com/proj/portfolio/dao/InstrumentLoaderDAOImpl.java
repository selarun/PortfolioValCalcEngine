package com.proj.portfolio.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.proj.portfolio.instrument.Instrument;
import com.proj.portfolio.trade.OptionType;
import com.proj.portfolio.trade.ProductType;

public class InstrumentLoaderDAOImpl implements InstrumentLoaderDAO {

	JdbcTemplate jdbcTemplate;

	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Collection<Instrument> getAllStocks() {
		return jdbcTemplate.query("SELECT * FROM STOCKMASTER", new StockInstrumentMapper());
	}

	@Override
	public Collection<Instrument> getAllOptions() {
		return jdbcTemplate.query("SELECT * FROM OPTIONMASTER", new OptionInstrumentMapper());
	}

	static class StockInstrumentMapper implements RowMapper<Instrument> {

		public Instrument mapRow(ResultSet rs, int rowNum) throws SQLException {
			Instrument instrument = new Instrument();
			instrument.setMasterid(rs.getLong(DBFieldNames.MASTERID.name()));
			instrument.setTicker(rs.getString(DBFieldNames.TICKER.name()));
			instrument.setRoe(rs.getDouble(DBFieldNames.ROE.name()));
			instrument.setClosePx(rs.getDouble(DBFieldNames.CLOSEPX.name()));
			instrument.setStandardDeviation(rs.getDouble(DBFieldNames.STDDEVIATION.name()));
			instrument.setProductType(ProductType.STOCK);
			instrument.setIssueName(rs.getString(DBFieldNames.ISSUENAME.name()));
			
			return instrument;

		}
	}

	static class OptionInstrumentMapper implements RowMapper<Instrument> {

		public Instrument mapRow(ResultSet rs, int rowNum) throws SQLException {

			Instrument instrument = new Instrument();
			instrument.setMasterid(rs.getLong(DBFieldNames.MASTERID.name()));
			instrument.setTicker(rs.getString(DBFieldNames.TICKER.name()));
			instrument.setUnderlyingTicker(rs.getString(DBFieldNames.UNDERLIERTICKER.name()));
			instrument.setStrikePrice(rs.getDouble(DBFieldNames.STRIKEPRICE.name()));
			instrument.setMaturityDate(rs.getDate(DBFieldNames.MATURITYDATE.name()));
			String securityType=rs.getString(DBFieldNames.SECURITYTYPE.name());
			if(securityType.startsWith("OC")) {
				instrument.setOptionType(OptionType.CALL);
			}
			else if(securityType.startsWith("OP")) {
				instrument.setOptionType(OptionType.PUT);
			}
			instrument.setProductType(ProductType.OPTION);
			instrument.setIssueName(rs.getString(DBFieldNames.ISSUENAME.name()));
			return instrument;

		}
	}

}
