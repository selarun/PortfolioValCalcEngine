package com.proj.portfolio.calc;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.trade.Side;
import com.proj.portfolio.trade.Trade;

public class PortfolioCalc {
	private static final Logger logger = LoggerFactory.getLogger(PortfolioCalc.class);

	public static double calculatePostionValue(Trade trade, Double currentPrice) throws PriceNotPublished {

		if (currentPrice == null)
			throw new PriceNotPublished("Price not Available for Ticker:" + trade.getTicker());

		double positionVal;
		// Assumption is Qty in the file for option is not in lots
		positionVal = trade.getQty() * currentPrice;
		if (trade.getSide() == Side.SELL) {
			return positionVal * -1;
		}
		logger.info("Value={} for Trade={}", positionVal, trade);
		return positionVal;

	}

	public static double calculatePortfolioValue(List<Trade> trades, Map<String, Double> currentPriceTickerMap)
			throws PriceNotPublished {

		double portFolioValue = 0;
		for (Trade trade : trades) {
			String ticker = trade.getTicker();
			portFolioValue += calculatePostionValue(trade, currentPriceTickerMap.get(ticker));
		}
		return portFolioValue;
	}
}