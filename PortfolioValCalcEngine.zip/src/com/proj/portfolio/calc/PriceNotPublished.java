package com.proj.portfolio.calc;

@SuppressWarnings("serial")
public class PriceNotPublished extends Exception {

	public PriceNotPublished(String message) {
        super(message);
    }

}
