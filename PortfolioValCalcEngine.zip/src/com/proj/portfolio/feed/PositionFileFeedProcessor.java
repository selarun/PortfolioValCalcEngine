package com.proj.portfolio.feed;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.proj.portfolio.instrument.InstrumentManager;
import com.proj.portfolio.instrument.InstrumentNotFoundException;
import com.proj.portfolio.trade.Side;
import com.proj.portfolio.trade.Trade;

/**
 * File format side,qty,ticker
 * 
 * @author ARUNKUMAR
 *
 */
public class PositionFileFeedProcessor implements IFeedProcessor<Trade> {

	private static final Logger logger = LoggerFactory.getLogger(PositionFileFeedProcessor.class);
	@Autowired
	private String feedFileName;

	@Autowired
	private String delim;

	public String getFeedFileName() {
		return feedFileName;
	}

	public void setFeedFileName(String feedFileName) {
		this.feedFileName = feedFileName;
	}

	public String getDelim() {
		return delim;
	}

	public void setDelim(String delim) {
		this.delim = delim;
	}

	@Override
	public List<Trade> processFeed() throws FeedException {
		List<Trade> trades = new ArrayList<>();
		Path path = FileSystems.getDefault().getPath(feedFileName);
		try {
			BufferedReader reader = Files.newBufferedReader(path, Charset.defaultCharset());
			String line = null;
			int lineCount = -1;
			while ((line = reader.readLine()) != null) {
				lineCount++;
				String positionData[] = line.split(delim);
				if (positionData.length < 3) {
					logger.error("Line Number={0} in the {1} file doesn't contain proper data", lineCount,
							feedFileName);
					continue;
				}
				trades.add(createTrade(positionData));
			}
		} catch (InstrumentNotFoundException e) {
			throw new FeedException(e.getMessage());
		} catch (IOException e) {
			throw new FeedException(e.getMessage());
		}
		return trades;
	}

	private Trade createTrade(String positionFeed[]) throws InstrumentNotFoundException {
		Trade trade = new Trade();

		trade.setSide(Side.valueOf(positionFeed[0])); // Side
		trade.setQty(Double.parseDouble(positionFeed[1]));// Qty
		String ticker = positionFeed[2]; // Ticker
		trade.setTicker(ticker);
		trade.setInstrument(InstrumentManager.getInstance().findInstrumentByTicker(ticker));

		return trade;
	}
}
