package com.proj.portfolio.feed;

import java.util.List;

public interface IFeedProcessor<T> {

	 List<T> processFeed() throws FeedException;
}
