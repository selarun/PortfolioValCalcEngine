package com.proj.portfolio.feed;

@SuppressWarnings("serial")
public class FeedException extends Exception {

	public FeedException(String message) {
        super(message);
    }

}
