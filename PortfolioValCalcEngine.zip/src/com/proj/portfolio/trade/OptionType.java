package com.proj.portfolio.trade;

public enum OptionType {
 CALL,PUT
}
