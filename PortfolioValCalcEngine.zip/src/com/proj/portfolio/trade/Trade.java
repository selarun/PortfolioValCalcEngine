package com.proj.portfolio.trade;

import com.proj.portfolio.instrument.Instrument;

public class Trade {
	private String ticker;

	private double qty;

	private Side side;

	private Instrument instrument;

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}

	public String getTicker() {
		return ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}	

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public Side getSide() {
		return side;
	}

	public void setSide(Side side) {
		this.side = side;
	}

	@Override
	public String toString() {
		return "Trade [ticker=" + ticker + ", qty=" + qty + ", side=" + side + ", instrument=" + instrument + "]";
	}

}
