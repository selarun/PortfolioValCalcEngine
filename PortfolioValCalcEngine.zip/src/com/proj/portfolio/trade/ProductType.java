package com.proj.portfolio.trade;

public enum ProductType {
STOCK,OPTION
}
