package com.proj.portfolio.trade;

public enum Side {

	BUY, SELL
}
