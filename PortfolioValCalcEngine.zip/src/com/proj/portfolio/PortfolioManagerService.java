package com.proj.portfolio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.feed.FeedException;
import com.proj.portfolio.feed.IFeedProcessor;
import com.proj.portfolio.marketdata.IMarketDataManager;
import com.proj.portfolio.marketdata.ITopOfBookListener;
import com.proj.portfolio.marketdata.MarketData;
import com.proj.portfolio.publisher.IPublisher;
import com.proj.portfolio.trade.Trade;

public class PortfolioManagerService implements ITopOfBookListener {

	private static final Logger logger = LoggerFactory.getLogger(PortfolioManagerService.class);

	private IFeedProcessor<Trade> feedProcessor;

	private Map<String, Double> tickerCurrentPrices = new ConcurrentHashMap<String, Double>();

	private List<Trade> trades = new ArrayList<>();

	private IPublisher consolePublisher;

	private IMarketDataManager marketDataManager;

	@PostConstruct
	public void process() {
		try {
			trades.addAll(feedProcessor.processFeed());
			subscribe(trades);
			marketDataManager.register(this);
		} catch (FeedException e) {
			logger.error("Error occured while processing the feed :{}", e.getMessage());
			System.exit(-1);
		}

	}

	private void subscribe(List<Trade> trades) {
		for (Trade trade : trades) {
			logger.info("Subscribing MarketData for Ticker={}", trade.getTicker());
			marketDataManager.subscribe(trade.getTicker());
		}
	}

	@Override
	public void updateMarketData(MarketData marketData) {
		logger.debug("Received MarketData:" + marketData);

		if (marketData.getCurrentPrice() != null) {
			tickerCurrentPrices.put(marketData.getTicker(), marketData.getCurrentPrice());
		}
		publish();
	}

	public void publish() {
		consolePublisher.publish(Collections.unmodifiableList(trades),
				Collections.unmodifiableMap(tickerCurrentPrices));
	}

	public IFeedProcessor<Trade> getFeedProcessor() {
		return feedProcessor;
	}

	public void setFeedProcessor(IFeedProcessor<Trade> feedProcessor) {
		this.feedProcessor = feedProcessor;
	}

	public IPublisher getConsolePublisher() {
		return consolePublisher;
	}

	public void setConsolePublisher(IPublisher consolePublisher) {
		this.consolePublisher = consolePublisher;
	}

	public IMarketDataManager getMarketDataManager() {
		return marketDataManager;
	}

	public void setMarketDataManager(IMarketDataManager marketDataManager) {
		this.marketDataManager = marketDataManager;
	}

	public List<Trade> getTrades() {
		return Collections.unmodifiableList(trades);
	}

	public Map<String, Double> getCurrentPricesForTicker() {
		return Collections.unmodifiableMap(tickerCurrentPrices);
	}
}
