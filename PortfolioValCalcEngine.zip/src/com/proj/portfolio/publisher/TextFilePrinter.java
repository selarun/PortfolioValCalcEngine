package com.proj.portfolio.publisher;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.calc.PortfolioCalc;
import com.proj.portfolio.calc.PriceNotPublished;
import com.proj.portfolio.trade.Side;
import com.proj.portfolio.trade.Trade;

public class TextFilePrinter implements IPublisher{

	private static final Logger logger = LoggerFactory.getLogger(TextFilePrinter.class);
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmm");
	private static final StringBuilder BUILDER = new StringBuilder();
	private static final String HEADER = "STATEMENT FOR CURRENT POSITIONS";
	private static final String LINE_SEP = System.getProperty("line.separator");
	private String outputFilePath;

	private String outFilename;

	public String getOutputFilePath() {
		return outputFilePath;
	}

	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

	public String getOutFilename() {
		return outFilename;
	}

	public void setOutFilename(String outFilename) {
		this.outFilename = outFilename;
	}

	@Override
	public void publish(List<Trade> trades, Map<String, Double> currentPriceTickerMap) {
		Path path = FileSystems.getDefault().getPath(outputFilePath,
				outFilename + "_" + DATE_FORMAT.format(Calendar.getInstance().getTime()) + ".txt");
		BufferedWriter writer = null;
		try {
			writer = Files.newBufferedWriter(path, Charset.defaultCharset(), StandardOpenOption.CREATE);
			writer.write(HEADER);
			BUILDER.append(LINE_SEP);
			for (Trade trade : trades) {
				String ticker = trade.getTicker();
				if (!currentPriceTickerMap.containsKey(ticker)) {
					
					writer.close();
				    Files.deleteIfExists(path);
				    return ;
				}
				double positionValue = PortfolioCalc.calculatePostionValue(trade, currentPriceTickerMap.get(ticker));
				formatPositionOutput(trade, positionValue);
				BUILDER.append(LINE_SEP);
			}
			
		    BUILDER.append("TOTAL VALUE OF THE PORTFOLIO IS :")
						.append(PortfolioCalc.calculatePortfolioValue(trades, currentPriceTickerMap));
			 
			writer.write(BUILDER.toString());
			writer.close();

		}
		catch (PriceNotPublished e) {
			logger.error("Text File generation is aborted");
			logger.error(e.getMessage());
			
		}
		catch (IOException e ) {
			logger.error("Issue generating Text Statement:" + e.getMessage());
			
		}
		finally {
			try {
				if(writer!=null) {
				writer.close();
				Files.deleteIfExists(path);
				}
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
	}

	private String formatPositionOutput(Trade trade, double positionValue) {
		BUILDER.append("Value of").append(trade.getSide() == Side.BUY ? "LONG" : "SHORT").append("POSITION FOR TICKER:")
				.append(trade.getTicker()).append(":=").append(positionValue);
		return BUILDER.toString();

	}

}
