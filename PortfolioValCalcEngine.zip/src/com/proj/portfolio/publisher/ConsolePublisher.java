package com.proj.portfolio.publisher;

import java.util.Calendar;
import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.calc.PortfolioCalc;
import com.proj.portfolio.calc.PriceNotPublished;
import com.proj.portfolio.trade.Trade;

public class ConsolePublisher implements IPublisher {

	private static final Logger logger = LoggerFactory.getLogger(ConsolePublisher.class);
	@Override
	public void publish(List<Trade> trades, Map<String, Double> currentPriceTickerMap) {
		double portFolioValue;
		try {
			portFolioValue = PortfolioCalc.calculatePortfolioValue(trades, currentPriceTickerMap);
			logger.info("*********************************************************************");
			logger.info("Current NAV of the PortFolio  = {} as of {} " , portFolioValue,Calendar.getInstance().getTime());
			logger.info("*********************************************************************");
		} catch (PriceNotPublished e) {
			logger.warn("Price for some of the securities is not published yet {}",e.getMessage());
		}
		

	}

}
