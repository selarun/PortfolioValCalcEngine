package com.proj.portfolio.publisher;

import java.util.List;
import java.util.Map;

import com.proj.portfolio.trade.Trade;

public interface IPublisher {

	void publish(List<Trade> trades, Map<String, Double> currentPriceTickerMap);
}