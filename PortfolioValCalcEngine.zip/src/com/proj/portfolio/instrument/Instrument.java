package com.proj.portfolio.instrument;

import java.util.Date;

import com.proj.portfolio.trade.OptionType;
import com.proj.portfolio.trade.ProductType;

public class Instrument {

	private long masterid;

	private String ticker;

	private double strikePrice;

	private double closePx;

	private double standardDeviation;

	private double roe;

	private String underlyingTicker;

	private double underlyingClosePrice;

	private double underlyingStandardDeviation;

	private String issueName;

	private ProductType productType;

	private OptionType optionType;

	private Date maturityDate;

	public String getTicker() {
		return ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public String getIssueName() {
		return issueName;
	}

	public void setIssueName(String issueName) {
		this.issueName = issueName;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getUnderlyingTicker() {
		return underlyingTicker;
	}

	public void setUnderlyingTicker(String underlyingTicker) {
		this.underlyingTicker = underlyingTicker;
	}

	public double getStrikePrice() {
		return strikePrice;
	}

	public void setStrikePrice(double strikePrice) {
		this.strikePrice = strikePrice;
	}

	public ProductType getProductType() {
		return productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	public OptionType getOptionType() {
		return optionType;
	}

	public void setOptionType(OptionType optionType) {
		this.optionType = optionType;
	}

	public double getClosePx() {
		return closePx;
	}

	public void setClosePx(double closePx) {
		this.closePx = closePx;
	}

	public double getUnderlyingClosePrice() {
		return underlyingClosePrice;
	}

	public void setUnderlyingClosePrice(double underlyingClosePrice) {
		this.underlyingClosePrice = underlyingClosePrice;
	}

	public double getUnderlyingStandardDeviation() {
		return underlyingStandardDeviation;
	}

	public void setUnderlyingStandardDeviation(double underlyingStandardDeviation) {
		this.underlyingStandardDeviation = underlyingStandardDeviation;
	}

	public double getStandardDeviation() {
		return standardDeviation;
	}

	public void setStandardDeviation(double standardDeviation) {
		this.standardDeviation = standardDeviation;
	}

	public double getRoe() {
		return roe;
	}

	public void setRoe(double roe) {
		this.roe = roe;
	}

	public long getMasterid() {
		return masterid;
	}

	public void setMasterid(long masterid) {
		this.masterid = masterid;
	}

	@Override
	public String toString() {
		return "Instrument [masterid=" + masterid + ", ticker=" + ticker + ", strikePrice=" + strikePrice + ", closePx="
				+ closePx + ", standardDeviation=" + standardDeviation + ", roe=" + roe + ", underlyingTicker="
				+ underlyingTicker + ", underlyingClosePrice=" + underlyingClosePrice + ", underlyingStandardDeviation="
				+ underlyingStandardDeviation + ", issueName=" + issueName + ", productType=" + productType
				+ ", optionType=" + optionType + ", maturityDate=" + maturityDate + "]";
	}

}
