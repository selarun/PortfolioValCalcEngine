package com.proj.portfolio.instrument;

@SuppressWarnings("serial")
public class InstrumentNotValid extends Exception {

	public InstrumentNotValid(String message) {
		super(message);
	}
}
