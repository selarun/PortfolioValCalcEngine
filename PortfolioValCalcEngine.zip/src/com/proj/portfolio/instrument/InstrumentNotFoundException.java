package com.proj.portfolio.instrument;

@SuppressWarnings("serial")
public class InstrumentNotFoundException extends Exception {

	public InstrumentNotFoundException(String message) {
		super(message);
	}
}
