package com.proj.portfolio.instrument;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.proj.portfolio.dao.InstrumentLoaderDAO;

/**
 * 
 * @author ARUNKUMAR
 *
 */
public class InstrumentManager {

	private static final Logger logger = LoggerFactory.getLogger(InstrumentManager.class);

	private static final InstrumentManager INSTRUMENT_MANAGER = new InstrumentManager();
	private Map<String, Instrument> instrumentByTicker = new ConcurrentHashMap<>();

	private InstrumentLoaderDAO instrumentLoader;

	private InstrumentManager() {

	}

	public static InstrumentManager getInstance() {
		return INSTRUMENT_MANAGER;
	}

	public InstrumentLoaderDAO getInstrumentLoader() {
		return instrumentLoader;
	}

	public void setInstrumentLoader(InstrumentLoaderDAO instrumentLoader) {
		this.instrumentLoader = instrumentLoader;
	}

	@PostConstruct
	public void populateInstruments() {
		for (Instrument instrument : instrumentLoader.getAllStocks()) {
			instrumentByTicker.put(instrument.getTicker(), instrument);
		}
		logger.info("Loaded {} Stocks", instrumentLoader.getAllStocks().size());

		for (Instrument instrument : instrumentLoader.getAllOptions()) {
			instrumentByTicker.put(instrument.getTicker(), populateUnderLyierDataForOPT(instrument));
		}
		logger.info("Loaded {} Options", instrumentLoader.getAllOptions().size());
	}

	private Instrument populateUnderLyierDataForOPT(Instrument instrument) {
		Instrument underLyierInstrument = instrumentByTicker.get(instrument.getUnderlyingTicker());
		instrument.setUnderlyingStandardDeviation(underLyierInstrument.getStandardDeviation());
		instrument.setUnderlyingClosePrice(underLyierInstrument.getClosePx());
		return instrument;
	}

	public Instrument findInstrumentByTicker(String ticker) throws InstrumentNotFoundException {
		Instrument instrument=instrumentByTicker.get(ticker);
		if(instrument == null) 
			throw new InstrumentNotFoundException("Instrument not available for Ticker"+ticker);
		return instrument;

	}

}
