package com.proj.portfolio;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PortFolioMain {
	@SuppressWarnings("resource")
	public static void main(String[] args) {		
		new ClassPathXmlApplicationContext("applicationContext.xml");
	}
}
